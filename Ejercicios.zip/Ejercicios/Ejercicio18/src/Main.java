import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        int [] arreglo = {2,82,64,264,94,274,274,24,55};

        Scanner numero = new Scanner(System.in);
        int a;
        System.out.println("Por favor ingrese un numero entero");
        a = numero.nextInt();
        int posicion = 0;
        int posicionencontrada = 0;
        int encontrado = 0;

        for(int c : arreglo){
            if (c == a){
                encontrado = c;
                posicionencontrada = posicion;
            }
            posicion = posicion + 1;
        }
        System.out.println("El numero " + encontrado + " fue encontrado dentro del arreglo en la posición " + posicionencontrada);
    }
}