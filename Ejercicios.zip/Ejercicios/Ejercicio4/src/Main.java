import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);
        System.out.println("Ingresa la cadena a convertir");
        String b = a.nextLine();
                    try{
                        int numero = Integer.parseInt(b);
                        System.out.println(b + " Se pudo convertir a entero");
                    }catch (Exception e){
                        System.out.println("No se puede convertir ");
                    }
                }
    }