public class Main {
    public static void main(String[] args) {

        int [] numeros = {5,100,0,1,54};
        int mayor = 0, menor = numeros[0];

        for (int a: numeros){
            if (a>mayor){
                mayor = a;
            }
            if (a < menor){
                menor = a;
            }
        }
        System.out.println("El numero mayor es: " + mayor);
        System.out.println("El numero menor es: " + menor);
    }
}