public class Main {
    public static void main(String[] args) {

        int [] numeros = {5, 89, 90,45,94};
        int promedio = 0;
        double promediocorrecto;

        for (int a : numeros){
            promedio = promedio + a;
        }
        promediocorrecto = promedio/5;

        System.out.println("El promedio es: " + promediocorrecto);

    }
}