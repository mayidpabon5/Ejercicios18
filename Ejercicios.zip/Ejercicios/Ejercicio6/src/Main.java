public class Main {
    public static void main(String[] args) {

        int [] cadena = {1,2,3,4,5};

        try{
                System.out.println("Las posiciones son: " + cadena [5]);
        }catch (Exception e){
            System.out.println("Estas intentando acceder a una posición inexistente: " + e.getMessage());;
        }
    }
}