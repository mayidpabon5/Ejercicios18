public class Main {
    public static void main(String[] args) {

        String[] nombres = {"Daniela", "Pedro", "Adriana", "Laura"};

        for (String a : nombres) {
            System.out.println("Los nombres de la cadena son: " + a);
        }
    }
}