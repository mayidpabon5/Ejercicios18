public class Main {
    public static void main(String[] args) {
        int[] arreglo1 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] arreglo2 = {100, 200, 300, 400,500,600,700,800,900,1000};
        int[] arreglo3 = new int[10];
        int posicion1 = 0;
        int posicion2 = 0;
        int posicion3 = 0;

        for (int d : arreglo1) {
            arreglo3[posicion1] = d;
            posicion1++;
        }
        for (int d : arreglo2) {
            arreglo1[posicion2] = d;
            posicion2++;
        }
        for (int d : arreglo3) {
            arreglo2[posicion3] = d;
            posicion3++;
        }

        for (int d : arreglo1) {
            System.out.println(d);
        }
        System.out.println("----------------------------------------------------");

        for (int d : arreglo2) {
            System.out.println(d);
        }
    }
}