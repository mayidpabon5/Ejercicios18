package paquete2;

import paquete1.Clase1;

public class Clase2 {

    Clase1 moto1 = new Clase1();
}
