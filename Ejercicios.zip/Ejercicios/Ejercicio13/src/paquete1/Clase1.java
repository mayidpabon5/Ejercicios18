package paquete1;

public class Clase1 {

    private String marca;
    private String modelo;
    private int ano;
    public int tamano;
    public double motor;
    protected String color;

    public Clase1(){
        marca = "susuki";
        modelo = "SK2000";
        ano = 2024;
        tamano = 160;
        motor = 1.5;
        color = "Azul";
    }
    public void cambiarColor(String color){
        this.color = color;
    }
}
