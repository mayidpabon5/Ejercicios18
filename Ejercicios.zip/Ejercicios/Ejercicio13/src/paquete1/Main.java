package paquete1;

import paquete1.Clase1;

public class Main {
    public static void main(String[] args) {


        Clase1 moto1 = new Clase1();
        moto1.
    }
}