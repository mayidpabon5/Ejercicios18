public class Main {
    public static void main(String[] args) {

        String[] arreglo = {"z", "p", "o", "y", "u", "r", "e"};
        int contador = 0;
        for (String a : arreglo) {

            if (a == "a") {
                contador = contador + 1;
            } else if (a == "e") {
                contador = contador + 1;
            } else if (a == "i") {
                contador = contador + 1;
            } else if (a == "o") {
                contador = contador + 1;
            } else if (a == "u") {
                contador = contador + 1;
            }
        }
        System.out.println("El arreglo tiene: " + contador + " Vocales");
    }
}