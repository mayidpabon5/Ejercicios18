public class Main {
    public static void main(String[] args) {

        int[] arreglooriginal = {100, 200, 300, 400, 500, 600, 700, 800, 900, 1000};
        int[] arregloinvertido = new int[10];
        int i, j;
        for (i = 9, j = 0; i <= 9 && j <= 9; i--, j++) {
            arregloinvertido[i] = arreglooriginal[j];
        }

        for (int a : arreglooriginal){
            System.out.println("El arreglo original es: " + a);
        }
        System.out.println("---------------------------");
        for (int a : arregloinvertido){
            System.out.println("El arreglo invertido es: " +a);
        }
    }

}