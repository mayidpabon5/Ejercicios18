package Coche;

public class Coche {

    String marca;
    String modelo;
    int ano;

    public Coche(String marca, String modelo, int ano) {

        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
    }

    public String informacionMarca() {
        return marca;
    }

    public String informacionModelo() {
        return modelo;
    }

    public int informacionano() {
        return ano;
    }
}
