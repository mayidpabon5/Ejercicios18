public class Main {
    public static void main(String[] args) {

        int [] numeros = {5,100,87,90,54};
        int mayor = 0, menor = 0;

            for (int a: numeros){
                if (a>mayor){
                    mayor = a;
                }
            }
        System.out.println("El numero mayor es: " + mayor);
    }
}