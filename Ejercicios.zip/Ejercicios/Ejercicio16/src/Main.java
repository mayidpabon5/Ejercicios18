public class Main {
    public static void main(String[] args) {

        int[] arreglo = {36213, 23823, 2365, 673, 118423, 1, 23734, 0, 7, 274};

        int mayor = 0;
        int menor = 0;
        int posicion = 0;
        for (int a : arreglo) {

            if (a > mayor) {
                mayor = a;
            }
            if (posicion == 0) {
                posicion = posicion + 1;
                menor = a;
            }
            if (a < menor) {
                menor = a;
            }
        }
        System.out.println("El mayor numero del arreglo es: " + mayor);
        System.out.println("El numero menor del arreglo es: " + menor);
    }
}