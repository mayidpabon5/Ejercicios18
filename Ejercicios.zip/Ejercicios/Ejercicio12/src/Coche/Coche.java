package Coche;

public class Coche {

    String marca;
    String modelo;
    int ano;

    public Coche(String marca, String modelo, int ano) {

        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
    }

    public void modificarMarca(String marca){
        this.marca = marca;
    }

    public void modificarModelo(String modelo){
        this.modelo = modelo;
    }

    public void modificarAno(int ano){
        this.ano = ano;
    }
    public String informacionMarca() {
        return marca;
    }

    public String informacionModelo() {
        return modelo;
    }

    public int informacionano() {
        return ano;
    }
}

