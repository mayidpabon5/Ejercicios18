package Ejecutable;

import Coche.Coche;

public class Main {
    public static void main(String[] args) {

        Coche automovil = new Coche("Mazda", "CX3", 2024);

        System.out.println("La marca del coche es: " + automovil.informacionMarca());
        System.out.println("El modelo del coche es: " + automovil.informacionModelo());
        System.out.println("El año del coche es: " + automovil.informacionano());

        automovil.modificarMarca("BMW");
        automovil.modificarModelo("BX6");
        automovil.modificarAno(2023);

        System.out.println("------------------Datos modificados---------------------------");
        System.out.println("La marca del coche es: " + automovil.informacionMarca());
        System.out.println("El modelo del coche es: " + automovil.informacionModelo());
        System.out.println("El año del coche es: " + automovil.informacionano());
    }



}