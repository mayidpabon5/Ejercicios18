import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        try{
            Scanner a = new Scanner(System.in);
            Scanner b = new Scanner(System.in);
            System.out.println("Ingresa el numero1");
            int c = a.nextInt();
            System.out.println("Ingresa el numero2");
            int d = b.nextInt();
            int resultado;
            resultado = c/d;
            System.out.println("La división es: " + resultado);
        }catch (Exception e){
            System.out.println("No se puede dividir por cero");
        }
    }
}