package Ejecutable;

import Animal.Animal;

public class Perro extends Animal {

    public static void main(String[] args) {

        Perro Kaiser = new Perro();

        System.out.println("El ladrido de Kaiser sera: " + Kaiser.hacerSonido("GUAU"));
    }
}