package Animal;

public class Animal {

    String sonido;
    public String hacerSonido(String sonido) {
    this.sonido = sonido;
    return sonido;
    }
}
