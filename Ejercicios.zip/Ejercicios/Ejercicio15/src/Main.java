import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);
        int [] b = new int[5];
        System.out.println("Ingrese el primer numero entero");
        b[0] = a.nextInt();
        System.out.println("Ingrese el segundo numero entero");
        b[1] = a.nextInt();
        System.out.println("Ingrese el tercer numero entero");
        b[2] = a.nextInt();
        System.out.println("Ingrese el cuarto numero entero");
        b[3] = a.nextInt();
        System.out.println("Ingrese el quinto numero entero");
        b[4] = a.nextInt();

        for (int c : b){
            System.out.println("Los valores del arreglo son: " + c);
        }
    }
}