import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);
        System.out.println("Ingrese un numero entero");
        int b = a.nextInt();
        int[] arreglo = {5, 6, 7, 1, 9, 10, 28, 2, 90, 100, 876, 26, 14, 18, 17, 33, 24};
        int d = 0;
        try {
            for (int c : arreglo) {
                if (b == c) {
                    System.out.println("el numero ingresado esta en la posición: " + d);
                }
                d = d + 1;
            }
        } catch (Exception e) {
            System.out.println("El numero ingresado no esta en el arreglo");
        }
    }
}